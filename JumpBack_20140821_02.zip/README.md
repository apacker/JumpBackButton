JumpBack Button ===============

August 21, 2014

Extension Created by Brian Slakter and Andrew Packer

This extension allows a user to navigate back in their browser history,
skipping over all pages that share the same URL root. For example, if a
user is searching for restaurants on Yelp, and navigates through the
pictures of one of the restaurants found in the search, this user would
normally have to click the back button multiple times to navigate back
through the pictures they just examined.  With one click of the JumpBack
Button, the user will be returned to their original restaurant search,
skipping over all images they have just looked at (as they share a
common URL root). 
